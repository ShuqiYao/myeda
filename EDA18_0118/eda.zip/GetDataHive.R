
library(RJDBC)
options(java.parameters='-Xmx8g')
cp = c(list.files("/data/soft/hive-2.0.0/lib", pattern = "[.]jar", full.names=TRUE, recursive=TRUE),
       list.files("/data/soft/hadoop-2.7.2/share/hadoop/common/lib", pattern = "[.]jar", full.names=TRUE, recursive=TRUE), 
       list.files("/data/soft/hadoop-2.7.2/etc/hadoop", full.names=TRUE, recursive=TRUE),
       list.files("/data/soft/hadoop-2.7.2/share/hadoop/hdfs", pattern = "[.]jar", full.names=TRUE, recursive=TRUE)
)
drv = JDBC(driverClass = "org.apache.hive.jdbc.HiveDriver", classPath = cp)
hiveconnection = dbConnect(drv,"jdbc:hive2://10.100.12.30:10000/dm_kg",user="kg", password="kg")


